# Claims cited by the draft

Status: draft v0.1.42; no actual submission freeze or paper tag exists yet.
External mathematical and specialist novelty review have not been performed.
Preparation baseline: `1132b287d6453d4c2f4d294ab1f9daa3154f1f59`.
The transport manifest records the exact later source snapshot separately.

The manuscript is restricted to the following registered claim and result
records.  Their registered tier, scope, hypotheses, and no-overclaim text are
the arbiter at any eventual submission commit.

| record | role in the manuscript | registered tier |
|---|---|---|
| `A2-FULL-PRODUCTION-WELLPOSED` | full three-component continuum functional, gradient-flow theorem, and scope firewall | T6 conditional theorem |
| `R-157` / `A2-PINNED-FUNCTIONAL-UNIQUE-ZERO-GLOBAL-MINIMIZER` | exact neutral energy and radial-derivative bounds; unique zero critical point; exponential decay | T6 conditional theorem extension |
| `R-158` / `A2-CHARGE-ENSEMBLE-FIRST-ORDER-SHELL-TRANSITION` | exact spectral shell, imposed-charge minimizer, grand-potential coexistence | T6 conditional theorem extension |
| `R-472` | non-bearing exact rational/Lean cross-check used only as assurance evidence | T0 claim-nonbearing audit |

The manuscript does not cite B1/Reading-H, Q3LOCK, A4, A7, T-050/A13,
Sector-A synthesis, or any physical-vacuum claim.  Its displayed mathematical
theorems are for the explicit functional; the registered conditional tiers
record provenance and govern only transfer to the canonical P1 interpretation.
The paper does not promote the registered A2 claim or alter its tier.

At submission, this file must be updated with the exact commit hash and the
paper tag required by `governance/publication-tiers.md`.  Until then, the
wording "draft" is mandatory.
